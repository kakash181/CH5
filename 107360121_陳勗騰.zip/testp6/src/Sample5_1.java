
public class Sample5_1 {
	public static void main(String[] args)
	{
		Car car1;
		car1 = new Car();
		car1.show();
	}
}
