package pa;

public class Sample5_2 {
	public static void main(String[] args)
	{
		Car car1;
		car1 = new Car();
		car1.show();
	}
}
